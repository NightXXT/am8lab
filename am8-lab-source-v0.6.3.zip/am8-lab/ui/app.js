'use strict';
const $=id=>document.getElementById(id), invoke=(name,args={})=>window.__TAURI__.core.invoke(name,args);
const state={busy:false,connected:false,pending:false,snapshot:null,dirty:new Set(),smoke:false,lastError:null};
const fields={
 noise:[['threshold','Limiar',-70,-20,-40,'dB'],['ratio','Intensidade',1,10,4,''],['attack','Ataque',1,100,10,'ms'],['release','Liberação',50,1000,200,'ms']],
 pitch:[['pitch','Altura',-3,3,0,'st']],
 voicepro:[['pitch','Altura',80,120,100,'%'],['formant','Timbre',90,110,110,'%']],
 reverb:[['mix','Sinal reverberado',0,60,60,'%'],['room','Tamanho da sala',0,60,60,'%'],['damping','Amortecimento',0,100,50,'%'],['wet_gain','Volume do efeito',-18,-6,-6,'dB']],
 plate:[['decay','Decaimento',20,60,40,'%'],['predelay','Pré-atraso',0,2500,2500,'amostras'],['damping','Amortecimento',0,100,50,'%'],['wet_gain','Volume do efeito',-18,-6,-6,'dB']],
 compressor:[['threshold','Limiar',-40,-6,-18,'dB'],['ratio','Razão',1,6,2,':1'],['attack','Ataque',1,100,10,'ms'],['release','Liberação',50,1000,200,'ms']],feedback:[]};
const titles={noise:'Redução de ruído',pitch:'Tom da voz',voicepro:'Transformação de voz Pro',reverb:'Reverberação',compressor:'Compressor',feedback:'Supressão de microfonia'};
const hints={noise:'Atenua sons baixos entre as palavras.',pitch:'Pro: −3 a +3 semitons. Use com Transformação Pro e Reverb desligados.',voicepro:'Altura e timbre independentes. Desativa o Tom da voz. Use com Reverb desligado.',reverb:'Experimental: foram relatados estalos na reprodução. Desative Tom da voz e Transformação Pro antes de usar.',compressor:'Controla a dinâmica em uma única faixa.',feedback:'Experimental. Redução de microfonia ainda não validada.'};
const drafts={};
for(const name of Object.keys(titles))drafts[name]={enabled:false,mode:name==='pitch'?'pitchpro':name,values:Object.fromEntries(fields[name].map(f=>[f[0],f[4]]))};
let eq={enabled:false,filters:Array.from({length:10},()=>({enabled:0,type:0,frequency:200,q:724,gain:0}))};
fields.pitchstandard=[['pitch','Altura',-12,12,0,'st']];
const fieldList=name=>fields[name==='reverb'?drafts.reverb.mode:name==='pitch'&&drafts.pitch.mode==='pitch'?'pitchstandard':name];
const display=(v,u)=>`${v>0&&['dB','st'].includes(u)?'+':''}${v}${u===':1'?u:u?' '+u:''}`;
function message(text,error=false){$('operationMessage').textContent=text;$('operationMessage').className=text?(error?'visible error':'visible'):'';}
function mark(name){state.dirty.add(name);const card=document.querySelector(`[data-effect="${name}"]`);if(card)card.querySelector('.card-status').textContent='Alterações preparadas';}
function renderCards(){
 $('effectCards').innerHTML=Object.entries(titles).map(([name,title])=>`<article class="panel" data-effect="${name}"><div class="panel-heading"><div><h2>${title}</h2>${['feedback','reverb'].includes(name)?'<span class="badge amber">Experimental</span>':''}</div><label class="toggle"><input data-enable type="checkbox" aria-label="Ativar ${title}" ${drafts[name].enabled?'checked':''}></label></div><p class="subtle card-hint">${hints[name]}</p>${name==='pitch'||name==='reverb'?`<div class="segmented">${(name==='pitch'?[['pitch','Padrão'],['pitchpro','Pro']]:[['reverb','Sala'],['plate','Plate']]).map(([mode,label])=>`<button data-mode="${mode}" class="${drafts[name].mode===mode?'selected':''}">${label}</button>`).join('')}</div>`:''}<div>${fieldList(name).map((f,i)=>`${name==='noise'&&i===2?'<details><summary>Controles avançados</summary>':''}<label class="field"><span>${f[1]}<output>${display(drafts[name].values[f[0]],f[5])}</output></span><input type="range" data-field="${f[0]}" min="${f[2]}" max="${f[3]}" step="1" value="${drafts[name].values[f[0]]}" aria-label="${f[1]}"></label>`).join('')}${name==='noise'?'</details>':''}</div><div class="card-footer"><span class="card-status">${state.dirty.has(name)?'Alterações preparadas':'Prepare e aplique'}</span><button data-apply class="small-button">Aplicar</button></div></article>`).join('');
 document.querySelectorAll('[data-effect]').forEach(card=>{
  const name=card.dataset.effect;
  card.querySelector('[data-enable]').onchange=e=>{drafts[name].enabled=e.target.checked;mark(name);};
  card.querySelectorAll('[data-field]').forEach(input=>input.oninput=()=>{drafts[name].values[input.dataset.field]=Number(input.value);const f=fieldList(name).find(f=>f[0]===input.dataset.field);input.closest('label').querySelector('output').textContent=display(Number(input.value),f[5]);mark(name);});
  card.querySelectorAll('[data-mode]').forEach(button=>button.onclick=()=>{drafts[name].mode=button.dataset.mode;if(name==='reverb')drafts[name].values=Object.fromEntries(fieldList(name).map(f=>[f[0],f[4]]));mark(name);renderCards();controls();});
  card.querySelector('[data-apply]').onclick=()=>operation('apply_effect',{effect:['pitch','reverb'].includes(name)?drafts[name].mode:name,enabled:drafts[name].enabled,values:drafts[name].values},false,name);
 });
}
function switchTab(tab){document.querySelectorAll('.tab-content').forEach(x=>x.classList.toggle('active',x.id==='tab-'+tab));document.querySelectorAll('#navTabs [data-tab]').forEach(x=>x.classList.toggle('nav-active',x.dataset.tab===tab));}
document.querySelectorAll('[data-tab]').forEach(button=>button.onclick=()=>switchTab(button.dataset.tab));
function controls(){
 const ready=state.connected&&!state.busy&&!state.snapshot?.comparison&&!state.snapshot?.legacy_pending&&!state.smoke;
 document.querySelectorAll('[data-effect] input,[data-effect] button,#eqFilters input,#eqFilters select,#eqQuick input,#eqEnabled,#eqApply,#eqHighpass,#eqLowpass,#eqFlat,#gainTest,#gainReduction').forEach(x=>x.disabled=!ready);
 $('restore').disabled=state.busy||!state.pending||state.smoke;
 $('btnCompareOriginal').disabled=state.busy||!state.connected||!state.pending||!!state.snapshot?.legacy_pending||state.smoke;
 for(const id of ['reconnect','reconnectBanner'])$(id).disabled=state.busy;
 $('compareText').textContent=state.snapshot?.comparison?'Voltar aos efeitos':'Comparar com original';
 $('bannerCompare').classList.toggle('hidden',!state.snapshot?.comparison);
 $('bannerDisconnected').classList.toggle('hidden',state.connected||state.busy);
 $('connLabel').textContent=state.busy?'Verificando / aplicando…':state.connected?'AM8 conectado por USB':'AM8 desconectado';
 $('connDot').style.background=state.connected?'#10b981':'#5a6172';
 if(!state.connected){$('firmware').textContent='Conecte o AM8 por USB';$('currentGainBadge').textContent='—';}
}
function snapshot(data,reset=false){
 state.snapshot=data;state.connected=true;state.pending=data.recovery_pending;if(reset)state.dirty.clear();
 const e=data.effects;
 for(const name of Object.keys(titles)){
  if(state.dirty.has(name))continue;const d=drafts[name];
  if(name==='pitch'){if(e.pitch_pro[0])d.mode='pitchpro';else if(e.pitch[0])d.mode='pitch';}
  if(name==='reverb'){if(e.plate_native[0])d.mode='plate';else if(e.reverb_native[0])d.mode='reverb';}
  const key={pitch:d.mode==='pitchpro'?'pitch_pro':'pitch',voicepro:'voice_pro',reverb:d.mode==='plate'?'plate_native':'reverb_native',feedback:'feedback_fine'}[name]||name,w=e[key];d.enabled=!!w[0];
  const v=name==='noise'?{threshold:w[1]/100,ratio:w[2],attack:w[3],release:w[4]}:name==='pitch'?{pitch:w[1]/10}:name==='voicepro'?{pitch:w[1],formant:w[2]}:name==='compressor'?{threshold:w[10]/100,ratio:w[14]/100,attack:w[18],release:w[22]}:name==='reverb'?(d.mode==='plate'?{decay:w[5],predelay:w[3],damping:w[6]/100,wet_gain:e.wet_route[2]/100}:{mix:w[2],room:w[4],damping:w[5],wet_gain:e.wet_route[2]/100}):{};
  d.values=Object.fromEntries(fieldList(name).map(f=>[f[0],(w[0]||state.pending)&&Number.isInteger(v[f[0]])&&v[f[0]]>=f[2]&&v[f[0]]<=f[3]?v[f[0]]:f[4]]));
 }
 if(!state.dirty.has('eq')){const w=e.eq;eq.enabled=!!w[0];eq.filters=Array.from({length:10},(_,i)=>{const j=3+i*5;return {enabled:w[j],type:w[j+1],frequency:w[j+2],q:w[j+3],gain:w[j+4]/256};});}
 $('firmware').textContent='Firmware '+data.firmware;$('currentGainBadge').textContent=data.gain_db.toFixed(1)+' dB';
 const names={noise:'Redução de ruído',pitch:'Tom padrão',pitch_pro:'Tom Pro',voice_pro:'Transformação Pro',reverb_native:'Reverb de sala',plate_native:'Reverb plate',feedback_fine:'Supressão de microfonia',compressor:'Compressor',eq:'Equalizador'};
 const active=Object.entries(names).filter(([key])=>e[key][0]);$('activeCount').textContent=active.length?active.length+' efeitos ativos':'Sem efeitos ativos';$('activeEffects').replaceChildren();
 for(const [,name] of active){const row=document.createElement('div');row.className='active-effect';row.textContent=name;$('activeEffects').append(row);}if(!active.length)$('activeEffects').textContent='Sua sessão está no estado original.';
 renderCards();renderEq();controls();
}
async function operation(name,args={},reset=false,applied=null,automatic=false){
 if(state.busy)return;if(!automatic)state.lastError=null;state.busy=true;controls();message('Aguardando confirmação do AM8…');
 try{const data=await invoke(name,args);if(applied)state.dirty.delete(applied);snapshot(data,reset);if(automatic&&state.lastError)message(state.lastError,true);else message(name==='restore_all'?'Sessão original restaurada.':name==='inspect'?'AM8 conectado e verificado.':'Ajuste confirmado no AM8.');}
 catch(error){state.connected=false;try{state.pending=await invoke('recovery_pending');}catch{}state.lastError=String(error)+(state.pending?' Reconecte e restaure a sessão.':'');message(state.lastError,true);}
 finally{state.busy=false;controls();}
}
$('btnCompareOriginal').onclick=() =>operation('compare_original');$('bannerCompare').querySelector('button').onclick=()=>operation('compare_original');
$('restore').onclick=()=>operation('restore_all',{},true);for(const id of ['reconnect','reconnectBanner'])$(id).onclick=()=>operation('inspect');
$('gainReduction').oninput=e=>$('gainReductionValue').textContent=e.target.value+' dB';$('gainTest').onclick=()=>operation('test_gain',{db:Number($('gainReduction').value)});

function renderEq(){
 $('eqEnabled').checked=eq.enabled;for(const [i,id] of ['quickBass','quickMid','quickTreble'].entries()){$(id).value=eq.filters[i].gain;$(id+'Val').textContent=display(eq.filters[i].gain,'dB');}$('eqFilters').innerHTML='<div class="eq-row eq-heading"><span>Filtro</span><span>Tipo</span><span>Frequência · Hz</span><span>Ganho · dB</span><span>Q</span></div>'+eq.filters.map((f,i)=>`<div class="eq-row"><label class="switch-label"><input type="checkbox" data-index="${i}" data-eq="enabled" ${f.enabled?'checked':''}> ${i+1}</label><select data-index="${i}" data-eq="type" aria-label="Tipo do filtro ${i+1}">${['Pico','Graves shelf','Agudos shelf','Passa-baixas','Passa-altas'].map((n,j)=>`<option value="${j}" ${f.type===j?'selected':''}>${n}</option>`).join('')}</select><input data-index="${i}" data-eq="frequency" type="number" min="20" max="16000" step="1" value="${f.frequency}" aria-label="Frequência do filtro ${i+1}"><input data-index="${i}" data-eq="gain" type="number" min="-6" max="6" step="1" value="${f.gain}" aria-label="Ganho do filtro ${i+1}"><input data-index="${i}" data-eq="q" type="number" min="0.25" max="8" step="0.01" value="${(f.q/1024).toFixed(2)}" aria-label="Q do filtro ${i+1}"></div>`).join('');
 $('eqFilters').querySelectorAll('[data-eq]').forEach(input=>input.onchange=()=>{const key=input.dataset.eq;let v=key==='enabled'?Number(input.checked):Number(input.value);if(key==='q')v=Math.round(v*1024);eq.filters[Number(input.dataset.index)][key]=v;mark('eq');$('eqStatus').textContent='Alterações preparadas';drawCurve();});
 $('eqStatus').textContent=state.dirty.has('eq')?'Alterações preparadas':'Valores confirmados';drawCurve();
}
function eqValues(){const v={};eq.filters.forEach((f,i)=>{for(const key of ['enabled','type','frequency','q','gain'])v[`f${i}_${key}`]=f[key];});return v;}
$('eqEnabled').onchange=e=>{eq.enabled=e.target.checked;mark('eq');};$('eqApply').onclick=()=>operation('apply_effect',{effect:'eq',enabled:eq.enabled,values:eqValues()},false,'eq');
for(const [id,type,hz] of [['eqHighpass',4,400],['eqLowpass',3,2500],['eqFlat',0,200]])$(id).onclick=()=>{eq.filters.forEach(f=>f.enabled=0);eq.filters[0]={enabled:id==='eqFlat'?0:1,type,frequency:hz,q:724,gain:0};eq.enabled=id!=='eqFlat';mark('eq');renderEq();controls();};
// Standard biquad response estimate at 44.1 kHz; no audio capture or processing.
function filterDb(f,hz){
 if(!f.enabled||!Number.isFinite(f.frequency)||!Number.isFinite(f.q)||f.q<=0)return 0;
 const w=2*Math.PI*f.frequency/44100,c=Math.cos(w),s=Math.sin(w),A=10**(f.gain/40),alpha=s/(2*f.q/1024),beta=2*Math.sqrt(A)*alpha;let b,a;
 if(f.type===0){b=[1+alpha*A,-2*c,1-alpha*A];a=[1+alpha/A,-2*c,1-alpha/A];}
 else if(f.type===3){b=[(1-c)/2,1-c,(1-c)/2];a=[1+alpha,-2*c,1-alpha];}
 else if(f.type===4){b=[(1+c)/2,-(1+c),(1+c)/2];a=[1+alpha,-2*c,1-alpha];}
 else if(f.type===1){b=[A*((A+1)-(A-1)*c+beta),2*A*((A-1)-(A+1)*c),A*((A+1)-(A-1)*c-beta)];a=[(A+1)+(A-1)*c+beta,-2*((A-1)+(A+1)*c),(A+1)+(A-1)*c-beta];}
 else{b=[A*((A+1)+(A-1)*c+beta),-2*A*((A-1)+(A+1)*c),A*((A+1)+(A-1)*c-beta)];a=[(A+1)-(A-1)*c+beta,2*((A-1)-(A+1)*c),(A+1)-(A-1)*c-beta];}
 const x=2*Math.PI*hz/44100,mag=v=>Math.hypot(v[0]+v[1]*Math.cos(x)+v[2]*Math.cos(2*x),v[1]*Math.sin(x)+v[2]*Math.sin(2*x));return 20*Math.log10(Math.max(1e-8,mag(b)/mag(a)));
}
function drawCurve(){
 let grid='';for(const y of [20,60,100,140,180])grid+=`<path d="M0 ${y}H920" stroke="#23262d"/>`;
 const boost=eq.filters.reduce((n,f)=>n+(f.enabled&&f.type<3?Math.max(0,f.gain):0),0);
 const pts=Array.from({length:230},(_,i)=>{const db=eq.filters.reduce((n,f)=>n+filterDb(f,20*(800**(i/229))),-boost);return `${i?'L':'M'}${i*920/229},${100-Math.max(-24,Math.min(24,db))*3.3}`;}).join(' ');
 $('eqCurve').innerHTML=grid+`<path d="M0 100H920" stroke="#3d424e" stroke-dasharray="4 5"/><path d="${pts}" fill="none" stroke="#a78bfa" stroke-width="2"/>`;
}
const profileKey='am8lab-profiles-v1',profileNameLimit=128;let profiles=[];
const isRecord=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const hasKeys=(value,keys)=>isRecord(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.hasOwn(value,key));
function profileValid(p){
 if(!hasKeys(p,['name','drafts','eq'])||typeof p.name!=='string'||!p.name.trim()||p.name.length>profileNameLimit)return false;
 if(!hasKeys(p.drafts,Object.keys(titles))||!hasKeys(p.eq,['enabled','filters'])||typeof p.eq.enabled!=='boolean'||!Array.isArray(p.eq.filters)||p.eq.filters.length!==10)return false;
 for(const name of Object.keys(titles)){const d=p.drafts[name];if(!hasKeys(d,['enabled','mode','values'])||typeof d.enabled!=='boolean'||!isRecord(d.values))return false;
  if(name==='pitch'&&!['pitch','pitchpro'].includes(d.mode)||name==='reverb'&&!['reverb','plate'].includes(d.mode))return false;
   if(!['pitch','reverb'].includes(name)&&d.mode!==name)return false;
   const list=fields[name==='reverb'?d.mode:name==='pitch'&&d.mode==='pitch'?'pitchstandard':name];if(!hasKeys(d.values,list.map(f=>f[0]))||list.some(f=>!Number.isInteger(d.values[f[0]])||d.values[f[0]]<f[2]||d.values[f[0]]>f[3]))return false;
 }
 return p.eq.filters.every(f=>hasKeys(f,['enabled','type','frequency','q','gain'])&&Object.entries({enabled:[0,1],type:[0,4],frequency:[20,16000],q:[256,8192],gain:[-6,6]}).every(([k,[lo,hi]])=>Number.isInteger(f[k])&&f[k]>=lo&&f[k]<=hi));
}
try{const raw=localStorage.getItem(profileKey)||'[]';if(raw.length<200000){const parsed=JSON.parse(raw);if(Array.isArray(parsed))profiles=parsed.filter(profileValid).slice(0,20);}}catch{}
function renderProfiles(){
 profiles=profiles.filter(profileValid).slice(0,20);
 $('profileList').replaceChildren();for(const [index,p] of profiles.entries()){
  const row=document.createElement('div');row.className='panel profile-row';const label=document.createElement('strong');label.textContent=typeof p.name==='string'?p.name:'Perfil';row.append(label);
  const actions=document.createElement('div');actions.className='flex gap-2';const load=document.createElement('button');load.className='small-button';load.textContent='Carregar controles';load.onclick=()=>{
   if(!profileValid(p)){message('Perfil inválido; nenhum ajuste enviado.',true);return;}
   for(const name of Object.keys(titles)){drafts[name]=structuredClone(p.drafts[name]);state.dirty.add(name);}eq=structuredClone(p.eq);state.dirty.add('eq');renderCards();renderEq();controls();message('Perfil carregado. Aplique os efeitos desejados.');
  };const remove=document.createElement('button');remove.className='small-button';remove.textContent='Excluir';remove.onclick=()=>{profiles.splice(index,1);try{localStorage.setItem(profileKey,JSON.stringify(profiles));}catch{}renderProfiles();};actions.append(load,remove);row.append(actions);$('profileList').append(row);
 }if(!profiles.length)$('profileList').textContent='Nenhum perfil salvo ainda.';
}
$('saveProfile').onclick=()=>{const name=$('profileName').value.trim();if(!name||name.length>profileNameLimit||profiles.length>=20){message('Informe um nome de até 128 caracteres. Limite: 20 perfis.',true);return;}const p={name,drafts:structuredClone(drafts),eq:structuredClone(eq)};if(!profileValid(p)){message('Revise os valores dos controles antes de salvar.',true);return;}try{profiles.push(p);localStorage.setItem(profileKey,JSON.stringify(profiles));$('profileName').value='';renderProfiles();message('Perfil salvo neste computador.');}catch{message('Não foi possível salvar o perfil.',true);}};

const meters={voice:{raw:0,view:0,peak:0,last:0},playback:{raw:0,view:0,peak:0,last:0}};let lastFrame=performance.now();
const meterVisual=raw=>raw<=0?0:Math.max(0,Math.min(1,(Math.log10(Math.max(raw,32))-Math.log10(32))/(Math.log10(32767)-Math.log10(32))));
function animate(now){
 const dt=Math.min(100,now-lastFrame);lastFrame=now;
 for(const [key,m] of Object.entries(meters)){
  if(!state.connected||now-m.last>400)m.raw=0;
  const target=meterVisual(m.raw);m.view=target>=m.view||matchMedia('(prefers-reduced-motion: reduce)').matches?target:m.view+(target-m.view)*(1-Math.exp(-dt/45));
  m.peak=m.view;
  for(const stem of key==='voice'?['mic','headerMic']:['playback','headerPlayback']){
   $(stem+'MeterFill').style.width=(m.view*100).toFixed(2)+'%';$(stem+'MeterPeak').style.width='2px';$(stem+'MeterPeak').style.left=(m.peak*100).toFixed(2)+'%';$(stem+'MeterVal').textContent=(m.raw/32767*100).toFixed(1)+'%';
  }
 }requestAnimationFrame(animate);
}
async function start(){
 renderCards();renderEq();renderProfiles();switchTab('overview');controls();requestAnimationFrame(animate);
 if(!window.__TAURI__){message('Prévia do design. O USB está disponível no aplicativo.',true);return;}
 state.smoke=await invoke('smoke_mode');
 if(await invoke('preview_mode')){state.smoke=true;controls();message('Prévia do design — sem comunicação USB.');return;}
 await window.__TAURI__.event.listen('operation-error',e=>{state.busy=false;message(e.payload,true);controls();});
 await window.__TAURI__.event.listen('closing-restore',()=>{state.busy=true;message('Restaurando os valores originais para fechar…');controls();});
 await window.__TAURI__.event.listen('meters',e=>{const d=e.payload,now=performance.now();if(d.sampled_at&&Date.now()-d.sampled_at>400)return;for(const key of ['voice','playback'])if(Number.isInteger(d[key])&&d[key]>=0&&d[key]<=32767){meters[key].raw=d[key];meters[key].last=now;}$('outputStatusText').textContent=d.output?'Saída padrão: '+d.output:'Saída padrão indisponível.';if(!d.connected){state.connected=false;controls();if(d.error&&!state.busy)message(d.error,true);}else if(!state.connected&&!state.busy)operation('inspect',{},false,null,true);});
 if(state.smoke){
  message('Verificação da interface — sem comunicação USB.');
  const sample={name:'Teste',drafts:structuredClone(drafts),eq:structuredClone(eq)};
  let passed=document.querySelectorAll('[data-effect]').length===6&&$('eqFilters').querySelectorAll('[data-eq="type"]').length===10&&profileValid(sample);
  for(const malformed of [null,[],0,'perfil',{}, {...sample,name:'x'.repeat(profileNameLimit+1)}, {...sample,drafts:[]}, {...sample,eq:{enabled:false,filters:Array(10).fill(null)}}])passed=passed&&!profileValid(malformed);
  const outOfRange=structuredClone(sample);outOfRange.eq.filters[0].gain=7;passed=passed&&!profileValid(outOfRange);
  const invalidValues=structuredClone(sample);invalidValues.drafts.noise.values=null;passed=passed&&!profileValid(invalidValues);
  const originalProfiles=profiles;profiles=[null,{...sample,name:'<img src=x onerror="alert(1)">'}];renderProfiles();
  passed=passed&&profiles.length===1&&$('profileList').querySelector('strong').textContent===profiles[0].name&&!$('profileList').querySelector('img');profiles=originalProfiles;renderProfiles();
  for(const tab of ['effects','eq','profiles','overview']){$('nav-tab-'+tab).click();passed=passed&&$('tab-'+tab).classList.contains('active');}
  passed=passed&&!$('eqCurve').innerHTML.includes('NaN');
  await invoke('finish_smoke',{passed});return;
 }
 await operation('inspect');
}
start().catch(error=>message(String(error),true));

for(const id of ['quickBass','quickMid','quickTreble'])$(id).oninput=()=>{
 const gains=['quickBass','quickMid','quickTreble'].map(x=>Number($(x).value));
 eq.filters.forEach(f=>f.enabled=0);
 for(const [i,[type,hz]] of [[1,150],[0,1200],[2,5000]].entries())eq.filters[i]={enabled:1,type,frequency:hz,q:724,gain:gains[i]};
 eq.enabled=true;mark('eq');renderEq();controls();
};
