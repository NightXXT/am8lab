# Instalação e verificação

Windows 10/11 x64. Escolha o setup nas Releases, confira o hash no PowerShell:

```powershell
Get-FileHash -LiteralPath .\AM8-Lab-Setup-v0.6.3.exe -Algorithm SHA256
```

Compare com SHA256SUMS.txt da mesma Release. Um hash confere integridade em relação à lista; uma lista alterada junto com o arquivo não oferece autenticidade. Este lançamento é sem assinatura Authenticode.

Execute o setup para o usuário atual. Há seletor Português/English, destino, atalhos e desinstalação nas configurações do Windows. WebView2 é detectado; se ausente, seu instalador oficial precisa acessar a internet. Não instala driver próprio nem altera a saída padrão do Windows.

Depois conecte o AM8 USB. A checagem do aparelho acontece no aplicativo e revisões não reconhecidas são recusadas. XLR sozinho não permite controle.

Antes de desinstalar, fechar normalmente e restaurar a sessão. O desinstalador não deve ser tratado como ferramenta de recuperação do DSP. Mantenha o diário se houver falha/desconexão. A versão portátil exige WebView2 já instalado.
