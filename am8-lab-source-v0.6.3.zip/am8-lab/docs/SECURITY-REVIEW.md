# Revisão inicial — 06/10/2026 — versão 0.6.3

## Escopo

Revisão local do backend Rust, UI, permissões Tauri, fronteiras de entrada, restauração e arquivos de distribuição; consulta cargo-audit 0.22.2 ao RustSec. Não é pentest independente, fuzzing amplo ou prova de ausência de vulnerabilidades. Não foram executados testes de ataque contra Windows, Discord, firmware ou rede. Diagnósticos físicos desta versão não modificaram o aparelho.

## Problemas corrigidos

| Item | Classificação | Correção |
|---|---|---|
| Recuperação pendente sem serial poderia ser usada em outro AM8 compatível | Integridade local / confiabilidade média | Exigir serial válido em journals não vazios, versões1–3; recusar mismatch antes de escrever; preservar arquivo |
| Limite64KiB era conferido depois de ler o arquivo inteiro | Negação de serviço local, baixa | Leitura limitada a64KiB+1 antes do parse |
| Perfis null/malformados podiam impedir inicialização | Disponibilidade local, baixa | Validação estrita, descarte de entradas inválidas, cap20 e nome até128 |
| Permissões core:default desnecessárias | Redução de superfície | Somente listen/unlisten e allowlist de comandos próprios via AppManifest |
| API Rust query(0x80,[]) podia indexar payload vazio | Confiabilidade local | Recusa antes do envio |
| Escrita de palavra no SDK permitia índices fora da descrição do bloco | Integridade local | Validar seletor, enable e faixa antes do envio |
| Duas sessões Windows poderiam controlar o aparelho | Confiabilidade | Mutex Global, mantendo Local para versões anteriores na mesma sessão |
| Dados extraídos e informações pessoais em arquivos de investigação | Distribuição / privacidade | Somente schema/fixture reduzidos e fingerprint; dumps, serial real, logs e backups excluídos; caminhos de compilação remapeados |

Nomes de perfil/erros/saída são tratados como texto. HTML dinâmico recebe valores validados; CSP bloqueia scripts remotos/inline, frames, objetos, base e envio de formulários. Sem plugins de shell, FS, HTTP ou abertura remota na UI. Esses controles não protegem contra malware com privilégios do usuário ou modificações arbitrárias do próprio processo.

## Dependências

`cargo audit --no-yanked --json`: **0 advisories classificados como vulnerabilities**, com dois avisos informativos no lockfile. Database commit `ef6173cbc5c50ec8166f9a5b28f07834144373ee`, atualização 03/10/2026. A checagem de crates yanked foi desativada nesta execução; não é uma checagem de malware nem de toda a cadeia de fornecimento.

- [RUSTSEC-2024-0370](https://rustsec.org/advisories/RUSTSEC-2024-0370.html): proc-macro-error1.0.4 sem manutenção.
- [RUSTSEC-2024-0429](https://rustsec.org/advisories/RUSTSEC-2024-0429.html): glib0.18.5 tem unsoundness no VariantStrIter; corrigido nas versões>=0.20.

`cargo tree --target x86_64-pc-windows-msvc -i glib` e `-i proc-macro-error` não encontram dependentes. Ambos aparecem no lockfile por dependências de outros alvos e não entram na compilação Windows deste projeto. Não suprimi os avisos no relatório ou no CI. Um port Linux exigirá revisão própria desses avisos.

Arquivo bruto da auditoria: [rustsec-audit.json](rustsec-audit.json). Catálogo/versões podem mudar; repetir a revisão antes de novos lançamentos.

## Validação e limites

18 testes Rust passaram: limites, dados de recuperação malformados, arquivos grandes, serial, falhas, desconexão, rollback, reinício, comparação e rotas. Smoke da interface passou com ACL reduzida, navegação, seis módulos, dez filtros, perfil/filtro null, limites e nome parecido com HTML renderizado literalmente. Compilação/setup e hash fazem parte da entrega final.

A verificação do fingerprint usa SHA-256 de2931bytes e não embute o grafo original. O firmware/layout USB ainda são restringidos aB5 0.7.1. O app salva o journal antes de toda mudança e tenta confirmar/voltar ao estado anterior quando a escrita falha.

Permanece limitação de hardware: reverb pode provocar estalos na reprodução; sua causa não foi determinada e o uso recomendado é sem reverb. A supressão de microfonia não teve eficácia acústica medida. Testes históricos em um único aparelho não comprovam qualidade em todas as combinações ou unidades. Binários não são assinados; o SHA-256 não substitui assinatura ou avaliação de confiança.

Validação de entrega: setup final instalado em pasta de teste com WebView2 já presente; somente app, licenças e desinstalador instalados. Smoke do app instalado passou; hash coincide com o portátil. Desinstalação terminou e o diário original permaneceu intacto. O ramo WebView2 ausente não foi executado nesta máquina. Workflow GitHub ainda não executado.
