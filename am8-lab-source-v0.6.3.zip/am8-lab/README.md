# AM8 Lab

[English](README.en.md) · [Segurança](SECURITY.md) · [Compilação](docs/BUILD.md)

Aplicativo **experimental e não oficial** para Windows que controla efeitos calculados pelo DSP do FIFINE AM8 USB. Rust + Tauri, interface em português baseada no design fornecido pelo usuário via Stitch. Não usa processamento de voz no PC ou microfone virtual.

## Instalar e usar

1. Na aba **Releases** deste repositório, baixe `AM8-Lab-Setup-v0.6.3.exe` e `SHA256SUMS.txt`.
2. Confira o SHA-256 conforme [Instalação](docs/INSTALL.md) e execute o setup. Instala para o usuário atual, cria atalhos e desinstalador. Se faltar WebView2, o bootstrapper oficial da Microsoft precisará de internet para instalar o runtime.
3. Conecte o AM8 por USB e abra AM8 Lab. O aplicativo verifica identidade, layout HID, versão e fingerprint do fluxo interno antes de permitir alterações.
4. Prepare os controles e pressione **Aplicar**. Use **Comparar com original** para ouvir a diferença e **Restaurar sessão** para reverter.
5. Feche normalmente; o programa restaura a sessão antes de sair. Se houver falha ou desconexão, reconecte e restaure.

O pacote `AM8-Lab-Portable-v0.6.3.zip` também está disponível nas Releases. O instalador e o app não têm assinatura Authenticode. O hash identifica o arquivo; não prova que ele é confiável nem equivale a uma assinatura.

## Compatibilidade

- Windows 10/11 **x64** e Microsoft Edge WebView2.
- AM8 normal via USB, VID:PID `3142:A010`, interface `MI_04`, B5 `0.7.1`, biblioteca `2.43.2`, engine `2.23.2`, modo HunXiang e fingerprint conhecido.
- Apenas uma revisão/aparelho recebeu os testes físicos iniciais. Outros AM8 podem ter hardware ou firmware diferentes; o aplicativo recusa revisões desconhecidas. O instalador não precisa do mic conectado.
- XLR não transporta os comandos USB. RGB e presença física de fones no P2 não são controlados.

## Efeitos e medidores

Ruído, EQ de dez filtros, compressor de uma faixa, tom padrão/Pro, transformação Pro e reverb Sala/Plate. Supressão de microfonia permanece experimental. Tom, transformação e reverb são limitados a um por vez.

**Reverb é experimental:** foram relatados estalos na reprodução dos fones que pararam ao desligá-lo. Para voz natural, use ruído + EQ + compressor, sem reverb. Afinação automática, echo e compressor multibanda não estão disponíveis.

Barras finas mostram leituras HID reais de voz e reprodução, com escala visual relativa, sem calibração em dB. Reprodução variável foi observada, mas não teve sincronização/escala completamente caracterizada. A saída padrão do Windows é consultada sem alterar seu roteamento.

Perfis ficam no computador e carregam os controles; cada efeito precisa ser aplicado. Nada é gravado na firmware. Ajustes são temporários e o diário `%LOCALAPPDATA%/AM8Lab/efeitos-recuperacao.json` permite restaurar após falhas. Não edite/apague esse arquivo quando houver ajustes pendentes. Recuperações pendentes sem serial válido são recusadas e preservadas.

## Relatar testes

Abra uma Issue descrevendo versão do app/Windows, firmware exibida, entrada USB ou XLR, onde ouviu o áudio, efeitos e passos para reproduzir. Não envie serial, caminhos pessoais ou diário completo. Para falhas de segurança, veja [SECURITY.md](SECURITY.md).

## Desenvolvimento

Veja [docs/BUILD.md](docs/BUILD.md), [CONTRIBUTING.md](CONTRIBUTING.md), [revisão de segurança](docs/SECURITY-REVIEW.md) e [origem dos dados](docs/PROVENANCE.md). O código não contém firmware/DLL extraída nem o grafo bruto do aparelho.

Licença MIT para o código original do projeto. Avisos de terceiros em [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md). FIFINE é marca de seus titulares; este projeto não é afiliado ou endossado por eles.
