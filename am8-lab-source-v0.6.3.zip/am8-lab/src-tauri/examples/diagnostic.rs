use am8_lab::{protocol::{Block, Effect, Result, Transport, read_meter}, session::Session, windows::{HidDevice, InstanceMutex}};
use std::{collections::BTreeMap, path::PathBuf};

fn main() {
    if let Err(error) = run() { eprintln!("{error}"); std::process::exit(1); }
}
fn run() -> Result<()> {
    let _instance = InstanceMutex::acquire()?;
    let path = PathBuf::from(std::env::var_os("LOCALAPPDATA").ok_or("LOCALAPPDATA ausente")?).join("AM8Lab/efeitos-recuperacao.json");
    let mut s = Session::open(path)?;
    let mut t = HidDevice::open()?;
    if std::env::args().any(|a| a == "--meter-timing") {
        t.guard()?;
        let mut runs = Vec::new();
        for wait_ms in [80, 8] {
            let mut samples = Vec::new();
            for _ in 0..60 {
                let start = std::time::Instant::now();
                let voice = t.meter_with_wait(0x91, wait_ms)?;
                let voice_ms = start.elapsed().as_secs_f64() * 1000.0;
                let playback = t.meter_with_wait(0x82, wait_ms)?;
                samples.push(serde_json::json!({"voice":voice,"playback":playback,"voice_ms":voice_ms,"pair_ms":start.elapsed().as_secs_f64()*1000.0}));
            }
            runs.push(serde_json::json!({"wait_ms":wait_ms,"samples":samples}));
        }
        println!("{}",serde_json::json!({"runs":runs}));
        return Ok(());
    }
    let before = s.inspect(&mut t)?;
    if std::env::args().any(|a| a == "--studio") {
        if s.pending() { return Err("Restaure a sessão existente antes do preset".into()); }
        if [Block::Pitch, Block::PitchPro, Block::VoicePro, Block::PlateNative].iter().any(|key| before.effects.get(key).is_some_and(|w| w[0] != 0)) {
            return Err("Desative tom, transformação e plate antes do preset de estúdio".into());
        }
        let mut eq = BTreeMap::new();
        let filters = [(4,80,724,0),(0,250,1024,-2),(0,3200,724,2),(2,8000,724,1)];
        for i in 0..10 {
            let (kind,hz,q,gain)=filters.get(i).copied().unwrap_or((0,200,724,0));
            for (key,v) in [("enabled",i32::from(i<filters.len())),("type",kind),("frequency",hz),("q",q),("gain",gain)] { eq.insert(format!("f{i}_{key}"),v); }
        }
        let values = |v: &[(&str,i32)]| v.iter().map(|(k,n)|((*k).to_string(),*n)).collect::<BTreeMap<_,_>>();
        let cases = [
            (Effect::Noise,values(&[("threshold",-45),("ratio",3),("attack",10),("release",250)])),
            (Effect::Eq,eq),
            (Effect::Compressor,values(&[("threshold",-18),("ratio",2),("attack",10),("release",200)])),
        ];
        let result: Result<_> = (|| {
            for (effect,values) in &cases {
                println!("Aplicando estúdio: {effect:?}");
                s.apply(&mut t,*effect,true,values.clone())?;
            }
            let active = s.inspect(&mut t)?;
            if s.compare(&mut t)?.effects != before.effects { return Err("Comparação difere do original".into()); }
            if s.compare(&mut t)?.effects != active.effects { return Err("Retomada do preset difere".into()); }
            Ok(active)
        })();
        let args: Vec<_> = std::env::args().collect();
        if let Some(i)=args.iter().position(|a| a=="--report") {
            if let Some(path)=args.get(i+1) {
                let report=serde_json::json!({"preset":"Estúdio natural","settings":cases,"before":before,"active":result.as_ref().ok(),"error":result.as_ref().err()});
                if let Err(e)=std::fs::write(path,serde_json::to_vec_pretty(&report).unwrap()) {
                    let recovery=s.restore(&mut t);
                    return Err(format!("Não foi possível salvar relatório: {e}. Restauração: {:?}",recovery.as_ref().err()));
                }
            }
        }
        match result {
            Ok(active) => { println!("{}",serde_json::to_string_pretty(&active).unwrap()); return Ok(()); }
            Err(e) => { let recovery=s.restore(&mut t);return Err(format!("{e}. Restauração: {:?}",recovery.as_ref().err())); }
        }
    }
    if std::env::args().any(|a| a=="--meters") {
        let mut values=Vec::new();
        for _ in 0..12 { values.push(serde_json::json!({"voice":read_meter(&mut t,0x91)?,"playback":read_meter(&mut t,0x82)?})); }
        println!("{}",serde_json::json!({"meters":values,"default_output":am8_lab::audio_status::default_output()}));return Ok(());
    }
    if std::env::args().any(|a| a == "--restore") {
        println!("{}", serde_json::to_string_pretty(&s.restore(&mut t)?).unwrap());
        return Ok(());
    }
    if !std::env::args().any(|a| a == "--validate-effects") {
        println!("{}", serde_json::to_string_pretty(&before).unwrap()); return Ok(());
    }
    if s.pending() { return Err("Restaure a sessão existente antes de validar".into()); }
    let raw_cases = [
        (Effect::Noise, vec![("threshold", -40),("ratio",4),("attack",10),("release",200)]), (Effect::Pitch, vec![("pitch", -1)]),
        (Effect::Eq, vec![("bass", -1), ("mid", 0), ("treble", 0)]),
        (Effect::Compressor, vec![("threshold", -18), ("ratio", 2), ("attack", 10), ("release", 200)]),
        (Effect::Pitchpro,vec![("pitch",-3)]),
        (Effect::Voicepro,vec![("pitch",100),("formant",110)]),
        (Effect::Reverb,vec![("mix",60),("room",60),("damping",50),("wet_gain",-6)]),
        (Effect::Plate,vec![("decay",40),("predelay",2500),("damping",50),("wet_gain",-6)]),
        (Effect::Feedback,vec![]),
    ];
    let mut cases: Vec<(Effect,BTreeMap<String,i32>)> = raw_cases.into_iter().map(|(effect,values)| (effect,values.into_iter().map(|(k,v)|(k.into(),v)).collect())).collect();
    if std::env::args().any(|a| a=="--full-eq") {
        let mut values=BTreeMap::new();
        for i in 0..10 {
            for (key,v) in [("enabled",if i==0 {1} else {0}),("type",if i==0 {4} else {0}),("frequency",if i==0 {400} else {200}),("q",724),("gain",0)] { values.insert(format!("f{i}_{key}"),v); }
        }
        cases=vec![(Effect::Eq,values)];
    }
    let arguments: Vec<_>=std::env::args().collect();
    if let Some(index)=arguments.iter().position(|a| a=="--only") {
        let name=arguments.get(index+1).ok_or("Missing effect name")?;
        let effect: Effect=serde_json::from_value(serde_json::Value::String(name.clone())).map_err(|e| e.to_string())?;
        cases.retain(|(candidate,_)| *candidate==effect);
    }
    let mut tests = Vec::new();
    let test_result: Result<()> = (|| {
        for (effect, values) in cases.iter().filter(|_| !std::env::args().any(|a|a=="--combined-only")) {
            println!("Validating {effect:?}");
            let values=values.clone();
            let during = s.apply(&mut t, *effect, true, values)?;
            println!("Applied {effect:?}");
            let comparison = s.compare(&mut t)?;
            println!("Compared {effect:?}");
            if comparison.effects != before.effects { return Err("Comparação não restaurou o estado original".into()); }
            let resumed = s.compare(&mut t)?;
            println!("Resumed {effect:?}");
            if resumed.effects != during.effects { return Err("Retomada dos efeitos não confere".into()); }
            let after = s.restore(&mut t)?;
            if after.effects != before.effects { return Err("Restauração não confere".into()); }
            tests.push(serde_json::json!({"effect": effect, "during": during, "restored": true}));
            println!("Confirmed and restored {effect:?}");
        }
        if cases.len()>1 {
        println!("Validating supported combination");
        for (effect, values) in cases.iter().filter(|(e,_)| !matches!(e,Effect::Pitch | Effect::Pitchpro | Effect::Voicepro | Effect::Reverb)) {
            println!("Combining {effect:?}");
            s.apply(&mut t, *effect, true, values.clone())?;
        }
        let combined = s.inspect(&mut t)?;
        if s.compare(&mut t)?.effects != before.effects { return Err("Combined comparison differs".into()); }
        if s.compare(&mut t)?.effects != combined.effects { return Err("Combined resumption differs".into()); }
        tests.push(serde_json::json!({"combined": combined}));
        }
        Ok(())
    })();
    let restoration = s.restore(&mut t);
    let args: Vec<_> = std::env::args().collect();
    if let Some(i) = args.iter().position(|a| a == "--report") {
        if let Some(path) = args.get(i + 1) {
            let report = serde_json::json!({"before":before,"tests":tests,"error":test_result.as_ref().err(),"after":restoration.as_ref().ok(),"restoration_error":restoration.as_ref().err()});
            std::fs::write(path, serde_json::to_vec_pretty(&report).unwrap()).map_err(|e| e.to_string())?;
        }
    }
    test_result?;
    let after = restoration?;
    if after.effects != before.effects { return Err("Estado final diferente do original".into()); }
    println!("All originals restored");
    Ok(())
}
